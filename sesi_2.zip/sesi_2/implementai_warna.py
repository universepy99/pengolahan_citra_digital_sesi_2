import numpy as np
import imageio.v3 as img


image_paths = [
    "C:\\Users\\ASUS VIVOBOOK GO14\\Documents\\test\\sesi_2\\kenikirrrr.jpg",
    "C:\\Users\\ASUS VIVOBOOK GO14\\Documents\\test\\sesi_2\Daun20Pepaya.jpg", 
    "C:\\Users\\ASUS VIVOBOOK GO14\\Documents\\test\\sesi_2\\singkong.jpg",
]

for idx, image_path in enumerate(image_paths):
   
    image = img.imread(image_path)
    
    
    if len(image.shape) < 3 or image.shape[2] != 3:
        print(f"Format gambar harus RGB untuk gambar ke-{idx+1}")
        continue
    
   
    red = image[:, :, 0]
    green = image[:, :, 1]
    blue = image[:, :, 2]
    
    
    image_red = np.zeros_like(image)
    image_green = np.zeros_like(image)
    image_blue = np.zeros_like(image)
    
    
    image_red[:, :, 0] = red
    image_green[:, :, 1] = green
    image_blue[:, :, 2] = blue
    
    
    img.imwrite(f"red_image_{idx+1}.jpg", image_red)
    img.imwrite(f"green_image_{idx+1}.jpg", image_green)
    img.imwrite(f"blue_image_{idx+1}.jpg", image_blue)
    
    
    recombined_image = np.stack((red, green, blue), axis=-1)
    img.imwrite(f"recombined_image_{idx+1}.jpg", recombined_image)
    
    
    gray = np.dot(image[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)
    img.imwrite(f"grayscale_image_{idx+1}.jpg", gray)
    
    
    threshold_1 = 85  
    threshold_2 = 170  
    
    binary_image = np.zeros_like(gray)
    binary_image[gray > threshold_1] = 1
    binary_image[gray > threshold_2] = 2
    
    img.imwrite(f"binary_image_{idx+1}.jpg", binary_image)

print("Proses Berhasil")
