import numpy as np
import imageio.v3 as img

image_path = "C:\\Users\\ASUS VIVOBOOK GO14\\Documents\\latihan\\sesi_2\\daun_kenikir.jpg"
image_path1 = "C:\\Users\\ASUS VIVOBOOK GO14\Documents\\latihan\sesi_2\\Daun20Pepaya.jpg"
image_path2 = "C:\\Users\\ASUS VIVOBOOK GO14\\Documents\\latihan\\sesi_2\\singkong.jpg"
image = img.imread(image_path)
image = img.imread(image_path1)
image = img.imread(image_path2)
if len(image.shape) < 3 or image.shape[2] != 3:
    print("Format gambar harus RGB")
    exit()

red = image[:,:,0]
green = image[:,:,1]
blue = image[:,:,2]

image_red = np.zeros_like(image)
image_green = np.zeros_like(image)
image
